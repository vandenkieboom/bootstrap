﻿using System.IO.Pipes;
using System.Security.Cryptography.X509Certificates;
using System.Collections.Immutable;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace OOPPractcing
{
    internal class Program
    {
        static void Main(string[] args)
        {
            FoodPurchase.DemoPurchase();
        }
    }
}

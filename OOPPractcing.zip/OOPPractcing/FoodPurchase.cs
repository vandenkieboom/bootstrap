﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPPractcing
{
	internal class FoodPurchase
	{
		//fields
		public bool Refrigerate;


		//props
		private string _productName;
		public string ProductName
		{
			get { return _productName.ToUpper(); }
		}

		private int _number;
		public int Number
		{
			get { return _number; }
			set
			{
				if (value <= 0)
				{
					throw new ArgumentException("Ongeldig aantal");
				}

				_number = value;
			}
		}

		private double _unitPrice;
		public double UnitPrice
		{
			get { return _unitPrice; }
			set
			{
				if (value < 0 || value > 5000)
				{
					throw new ArgumentOutOfRangeException("Ongeldige eenheidsprijs");
				}

				_unitPrice = value;
			}
		}

		public DateTime ExpirationDate
		{
			get
			{
				DateTime current = DateTime.Now;
				return current.AddMonths(2);

			}
		}


        //constructors
        public FoodPurchase(string productName, byte number, double unitPrice, bool refrigerate)
        {
			this._productName = productName;
			this.Number = number;
			this.UnitPrice = unitPrice;
			this.Refrigerate = refrigerate;
        }


		//methodes
		public double CalculateTotalPrice()
		{
			return UnitPrice * Number;
		}

		public static void DemoPurchase()
		{
			try
			{
				FoodPurchase kaas = new FoodPurchase("kaas", 2, 2.45, true);
				double totalPrice = kaas.CalculateTotalPrice();
				Console.WriteLine($"De totaalprijs van {kaas.ProductName} is {totalPrice}\nDe vervaldatum van aankoop 1 is {kaas.ExpirationDate}");

				FoodPurchase boter = new FoodPurchase("boter", 0, 5555, true);
			}
			catch (ArgumentException e)
			{
				Console.WriteLine(e.Message);
			}
			catch (Exception e)
			{
                Console.WriteLine(e.Message);
            }
		}
	}
}
